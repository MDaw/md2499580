/* 
 * File:   main.cpp
 * Author: Marwah Dawoody
 * Created on January 19, 2014, 5:23 PM
 * write a program that will calculate the user's 
 * monthly and annual automobile costs
 */

//System Libraries
#include <iostream>
using namespace std;
//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float loanpay, insure, gas, oil, tires, mainten, monthly, yearly;
    
   //output the initial question 
    cout<<"How much do you pay a month for your car's loan payments, insureance, gas,"<<endl;
    cout<<" oil, tires, and maintenance?"<<endl;
   //user will input their information
    cin>>loanpay>>insure>>gas>>oil>>tires>>mainten;
   //calculate the monthly payments
    monthly=loanpay+insure+gas+oil+tires+mainten;
   //calculate the yearly payments
    yearly=(loanpay+insure+gas+oil+tires+mainten)*12;
   //output the results
    cout<<"Your monthly expenses are $"<<monthly<<" and your yearly expenses are $"<<yearly<<endl;       
    
   //Exit Stage Right
    return 0;
}

