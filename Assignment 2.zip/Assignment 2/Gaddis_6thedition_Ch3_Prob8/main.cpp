/* 
 * File:   main.cpp
 * Author: Marwah Dawoody
 * Created on January 19, 2014, 5:09 PM
 * write a program that will tell owners the minimum amount they should insure 
 * they need for their homes 
 */

//System Libraries
#include <iostream>
using namespace std;
//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float RepCost,MinIn;
    //output the initial question
    cout<<"How much is it going to cost you to repair your home?"<<endl;
    cin>>RepCost;
    cout<<"The minimum amount of insurance you would need is "<<MinIn<<endl;
    //calculate the 80% of the repair costs
    MinIn=RepCost*0.80;
    
    
    //Exit Stage Right
    return 0;
}

