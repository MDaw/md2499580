/* 
 * File:   main.cpp
 * Author: Marwah Dawoody
 * Created on January 18, 2014, 6:36 PM
 * write a program that will average out 5 test scores
 */

//System Libraries
#include <iostream>
using namespace std;
//Global Constants

//Function Prototypes

//Execution Begins here
int main(int argc, char** argv) {
    //Declare Variables
    float score1,score2,score3,score4,score5,avgSco;
    
    //output initial question "type in 5 test scores to be averaged out"
     cout<<"Type in 5 test scores to be averaged out"<<endl;
    //the user will inpout their 5 scores
     cin>>score1>>score2>>score3>>score4>>score5;
    //calculate the average test score based upon the scores that were inputed
     avgSco=(score1+score2+score3+score4+score5)/5;
    //output the average score
     cout<<"The average test score would be "<<avgSco<<endl;        
    
    //Exit Stage Right
    return 0;
}

