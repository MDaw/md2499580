/* 
 * File:   main.cpp
 * Author: Marwah Dawoody
 * write a program that will calculate the selling price of a circuit 
 * board that costs $12.67 with a 40% profit
 */

//System Libraries
#include <iostream>
using namespace std;
//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
  //Declare Variables
    float board=12.67, profit=0.4, sellpri;
  
  //Calculate the selling price of the circuit board
    sellpri=board*profit;
  //output the results
    cout<<"The selling price of a circuit board is "<<sellpri<<" so for every"<<endl;
    cout<<"circuit board the company makes about $5.01"<<endl;
    
  //Exit Stage Right  
    return 0;
}

