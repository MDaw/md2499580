/* 
 * File:   main.cpp
 * Author: Marwah Dawoody
 * write a program that will stores two integers and their sums
 */

//System Libraries
#include <iostream>
using namespace std;
//Global COnstants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
//Declare Variables
    int int1=62,int2=99,sum;
    sum=int1+int2;
    
//output the stored value
    cout<<int1<<" + "<<int2<<" = "<<sum<<endl;

//Exit Stage Right    
    return 0;
}

