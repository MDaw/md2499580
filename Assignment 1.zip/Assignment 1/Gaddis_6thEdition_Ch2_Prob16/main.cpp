/* 
 * File:   main.cpp
 * Author: Marwah Dawoody
 * write a program that will output a diamond patteren out of *
 */

//System Libraries
#include <iostream>
using namespace std;
//Global COnstants

//Function Prototypes

//Execution beginsHere
int main(int argc, char** argv) {
  
  //output the diamond pattern  
    cout<<"   *   "<<endl;
    cout<<"  ***  "<<endl;
    cout<<" ***** "<<endl;
    cout<<"*******"<<endl;
    cout<<" ***** "<<endl;
    cout<<"  ***  "<<endl;     
    cout<<"   *   "<<endl;       
             
  //Exit Stage Right  
    return 0;
}

