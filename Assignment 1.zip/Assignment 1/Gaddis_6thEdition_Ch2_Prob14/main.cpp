/* 
 * File:   main.cpp
 * Author: Marwah Dawoody
 * write a program that will display personal information on separate lines 
 */

//System Libraries
#include <iostream>
using namespace std;
//Global Constants

//Function prototypes

//Execution Begins here
int main(int argc, char** argv) {
  //Declare Variables
    cout<<"Your Name: "<<endl; 
    cout<<"Your address (city, state, zip): "<<endl;
    cout<<"Your Telephone Number: "<<endl;
    cout<<"Your College Major: "<<endl;
    return 0;
}

